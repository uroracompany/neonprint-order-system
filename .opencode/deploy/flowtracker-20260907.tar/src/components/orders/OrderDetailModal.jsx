import { useEffect, useState } from "react";
import { supabase } from "../../../supabaseClient";
import { Icons } from "../../utils/icons";
import {
  ORDER_STATUS,
  getFileNameFromUrl,
  isOrderStatusIn,
} from "../../utils/constants";
import { getOrderFiles, getReferenceImages, hasAnyOrderAsset } from "../../utils/orderAssets";
import { resolveOrderAssetUrl } from "../../utils/fileAccess";
import { FlowTracker, FlowTrackerExternal } from "../FlowTracker";
import FileCard from "../FileCard";
import { PaymentBadge, StatusBadge as SharedStatusBadge } from "../ui/Badge";
import { Modal } from "./CreateOrderModal";
import OrderAssignmentAction from "./OrderAssignmentAction";
import OrderReviewCard from "./OrderReviewCard";
import { OrderReturnHandoffPanel } from "./OrderReturnHandoff";
import OrderParticipationTimeline from "./OrderParticipationTimeline";
import "./OrderDetailModal.css";

const ACTIVE_WORKFLOW_STATUSES_FOR_SELLER = [
  ORDER_STATUS.IN_DESIGN,
  ORDER_STATUS.IN_QUOTE,
  ORDER_STATUS.IN_PRODUCTION,
  ORDER_STATUS.IN_TERMINATION,
  ORDER_STATUS.IN_DELIVERED,
  ORDER_STATUS.IN_COMPLETED,
  ORDER_STATUS.CANCELLED,
];

const isReturnedOrder = (order) => {
  if (!order || !order.return_reason) return false;
  const validStatuses = order.order_design_type === "EXTERNAL_DESING"
    ? [ORDER_STATUS.PENDING]
    : [ORDER_STATUS.IN_DESIGN];
  return isOrderStatusIn(order.status, validStatuses);
};

const getPreviewAssetKey = (url) => `preview:${url}`;
const getReferenceAssetKey = (url, index) => `reference:${index}:${url}`;

function StatusBadge({ status, type = "status", order = null }) {
  if (type === "payment") {
    return <PaymentBadge status={status} className="ps-badge" bordered />;
  }
  return <SharedStatusBadge status={status} className="ps-badge" showDot bordered order={order} />;
}

function ReturnedBadge({ compact = false }) {
  return (
    <span className={`ps-returned-badge${compact ? " compact" : ""}`} title="Orden devuelta desde caja">
      Devuelta
    </span>
  );
}

function TrackingLinkField({ orderId }) {
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!orderId) return;
    setLoading(true);
    supabase
      .from("orders")
      .select("tracking_token")
      .eq("id", orderId)
      .single()
      .then(({ data }) => {
        if (data?.tracking_token) setToken(data.tracking_token);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [orderId]);

  const trackingUrl = token ? `${window.location.origin}/track/${token}` : null;

  const handleCopy = async () => {
    if (!trackingUrl) return;
    try {
      await navigator.clipboard.writeText(trackingUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const textArea = document.createElement("textarea");
      textArea.value = trackingUrl;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand("copy");
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (loading) {
    return (
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "4px 0" }}>
        <div style={{ width: 14, height: 14, border: "2px solid var(--border)", borderTopColor: "var(--primary)", borderRadius: "50%" }} />
        <span style={{ fontSize: 12, color: "var(--text-muted)" }}>Cargando...</span>
      </div>
    );
  }

  return (
    <div>
      {trackingUrl ? (
        <div style={{ display: "flex", gap: 8 }}>
          <input
            type="text"
            readOnly
            value={trackingUrl}
            onClick={(event) => event.target.select()}
            style={{
              flex: 1,
              padding: "8px 12px",
              fontSize: 12,
              fontWeight: 600,
              fontFamily: "'SF Mono', 'Fira Code', monospace",
              border: "1.5px solid var(--border)",
              borderRadius: "var(--radius-sm)",
              background: "var(--surface-alt)",
              color: "var(--text)",
              outline: "none",
              cursor: "text",
            }}
          />
          <button
            onClick={handleCopy}
            style={{
              padding: "8px 14px",
              background: copied ? "#10B981" : "var(--primary)",
              border: "none",
              borderRadius: "var(--radius-sm)",
              color: "#fff",
              fontSize: 12,
              fontWeight: 600,
              cursor: "pointer",
              whiteSpace: "nowrap",
              transition: "background 0.2s",
              fontFamily: "'Poppins', sans-serif",
            }}
          >
            {copied ? "✓ Copiado" : "Copiar"}
          </button>
        </div>
      ) : (
        <p style={{ fontSize: 12, color: "var(--text-muted)", margin: 0, fontStyle: "italic" }}>
          El link estará disponible cuando la orden tenga un token de seguimiento.
        </p>
      )}
    </div>
  );
}

export default function OrderDetailModal({
  open,
  onClose,
  order,
  user,
  responsibleName,
  designerName: designerNameProp,
  onSendToDesigner,
  onSendToQuotation,
  primaryActionLabel,
  showPrimaryAction = true,
  pendingReview = null,
  onAcknowledgeReview,
  reviewAcknowledging = false,
  reviewError = "",
  returnHandoff = null,
  returnHistory = [],
  onReturnToCashier,
  adminIntervention = null,
  adminActions = null,
  closeOnBackdrop = true,
  closeOnEscape = true,
}) {
  const hasOrder = Boolean(order);
  const created = hasOrder ? new Date(order.created_at).toLocaleString("es-DO", { dateStyle: "medium", timeStyle: "short" }) : "";
  const orderFileUrls = getOrderFiles(order);
  const referenceImageUrls = getReferenceImages(order);
  const hasAssets = hasAnyOrderAsset(order);
  const [designerName, setDesignerName] = useState("");
  const [resolvedAssetUrls, setResolvedAssetUrls] = useState({});
  const [assetResolutionErrors, setAssetResolutionErrors] = useState({});
  const referenceImagesKey = referenceImageUrls.join("\u001f");

  useEffect(() => {
    if (designerNameProp) {
      setDesignerName(designerNameProp);
      return;
    }

    if (!order?.designer_id) {
      setDesignerName("");
      return;
    }

    supabase
      .from("profiles")
      .select("name")
      .eq("id", order.designer_id)
      .single()
      .then(({ data }) => {
        if (data?.name) {
          setDesignerName(data.name);
        } else {
          setDesignerName("Diseñador");
        }
      });
  }, [designerNameProp, order?.designer_id]);

  useEffect(() => {
    if (!open || !order?.id) {
      setResolvedAssetUrls({});
      setAssetResolutionErrors({});
      return undefined;
    }

    const assets = [
      ...(order.preview_image ? [{ key: getPreviewAssetKey(order.preview_image), url: order.preview_image }] : []),
      ...referenceImageUrls.map((url, index) => ({
        key: getReferenceAssetKey(url, index),
        url,
      })),
    ];
    let active = true;

    setResolvedAssetUrls({});
    setAssetResolutionErrors({});

    assets.forEach(({ key, url }) => {
      resolveOrderAssetUrl(url)
        .then((resolvedUrl) => {
          if (!active) return;
          setResolvedAssetUrls((current) => ({ ...current, [key]: resolvedUrl }));
        })
        .catch(() => {
          if (!active) return;
          setAssetResolutionErrors((current) => ({ ...current, [key]: true }));
        });
    });

    return () => {
      active = false;
    };
  }, [open, order?.id, order?.preview_image, referenceImagesKey]);

  if (!hasOrder) return null;

  const isExternalDesign = order.order_design_type === "EXTERNAL_DESING";
  const isReturningToCashier = Boolean(returnHandoff && !returnHandoff.responded_at);
  const primaryActionHandler = isReturningToCashier ? () => onReturnToCashier?.(returnHandoff) : (isExternalDesign ? onSendToQuotation : onSendToDesigner);
  const primaryLabel = isReturningToCashier ? "Regresar a Caja" : (primaryActionLabel || (isExternalDesign ? "Enviar a Caja" : "Enviar a Diseño"));
  const shouldShowPrimaryAction = showPrimaryAction
    && (isReturningToCashier || !isOrderStatusIn(order.status, ACTIVE_WORKFLOW_STATUSES_FOR_SELLER));
  const displayResponsibleName = responsibleName || user?.displayName || "---";

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={`Orden #${order.id?.slice(0, 8).toUpperCase()}`}
      wide
      className="order-detail-modal"
      closeOnBackdrop={closeOnBackdrop}
      closeOnEscape={closeOnEscape}
      hideStripe
      overlayClassName="order-detail-modal-overlay"
    >
      <div className="order-detail-shell">
        <div className="order-detail-flow" role="region" aria-label="Progreso de la orden" tabIndex={0}>
          {isExternalDesign ? (
            <FlowTrackerExternal status={order.status} />
          ) : (
            <FlowTracker status={order.status} />
          )}
        </div>

        {adminActions && (
          <section className="order-detail-actions-panel" aria-label="Acciones de la orden">
            <div className="order-detail-actions-copy">
              <strong>Acciones de la orden</strong>
              <span>Gestiona esta orden sin volver al listado.</span>
            </div>
            {adminActions}
          </section>
        )}

        {adminIntervention}

      <div className="order-detail-content-grid">
        <div className="order-detail-column">
          <div className="order-detail-section" style={{
            background: "var(--surface)",
            padding: 20,
            marginBottom: 18,
          }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 14, marginBottom: 16 }}>
              <div style={{
                width: 50, height: 50,
                borderRadius: "50%",
                background: "var(--primary)",
                display: "flex", alignItems: "center", justifyContent: "center",
                color: "#fff", fontSize: 18, fontWeight: 700,
                flexShrink: 0,
                letterSpacing: "0.02em"
              }}>
                {order.client_name?.split(" ").slice(0, 2).map(n => n.charAt(0)?.toUpperCase()).join("") || "?"}
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 16, fontWeight: 700, color: "var(--text)", margin: 0, marginBottom: 5 }}>
                  {order.client_name}
                </p>
                {order.client_contact && (
                  <span style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 5,
                    padding: "4px 10px",
                    background: "var(--surface-alt)",
                    border: "1px solid var(--border)",
                    borderRadius: 20,
                    fontSize: 12,
                    fontWeight: 600,
                    color: "var(--text)"
                  }}>
                    <Icons.Phone />{order.client_contact}
                  </span>
                )}
              </div>
            </div>

            <div style={{ paddingTop: 14, borderTop: "1px solid var(--border)" }}>
              <p style={{
                fontSize: 11, fontWeight: 700, color: "#1E40AF",
                textTransform: "uppercase", letterSpacing: "0.07em",
                margin: "0 0 10px 0",
                display: "flex", alignItems: "center", gap: 6
              }}>
                <Icons.FileText /> Descripción de la orden
              </p>
              <p style={{ fontSize: 13, color: "var(--text)", fontWeight: 600, lineHeight: 1.6, margin: 0 }}>
                {order.description}
              </p>
            </div>
          </div>

          <OrderReviewCard
            pendingReview={pendingReview}
            onAcknowledge={onAcknowledgeReview}
            acknowledging={reviewAcknowledging}
            error={reviewError}
          />

          <div className="order-detail-section" style={{
            background: "var(--surface)",
            padding: 20,
            marginBottom: 18
          }}>
            <p style={{
              fontSize: 11, fontWeight: 700, color: "#1E40AF",
              textTransform: "uppercase", letterSpacing: "0.07em",
              marginBottom: 14, margin: "0 0 14px 0",
              display: "flex", alignItems: "center", gap: 6
            }}><Icons.Clipboard /> Especificaciones</p>

            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {[
                { label: "Material", value: order.material, icon: <Icons.Paintbrush /> },
                { label: "Tipo de terminación", value: order.termination_type || "---", icon: <Icons.Check /> },
                { label: "Tipo de orden", value: order.order_type, icon: <Icons.Package /> },
                { label: "Núm. Facturación", value: order.invoice_number || "---", icon: <Icons.FileText /> },
                {
                  label: "Diseño",
                  value: order.order_design_type === "INTERNAL_DESING" ? "Diseño interno" :
                    order.order_design_type === "EXTERNAL_DESING" ? "Diseño externo" : "---",
                  icon: <Icons.Edit />
                },
                { label: "Fecha entrega", value: order.delivery_date || "Indefinida", icon: <Icons.Calendar /> },
              ].map((item, index) => (
                <div key={item.label} style={{
                  display: "grid", gridTemplateColumns: "28px 1fr auto",
                  gap: 10, alignItems: "center", paddingBottom: 11,
                  borderBottom: index < 5 ? "1px solid var(--border)" : "none"
                }}>
                  <div style={{ color: "var(--pink)" }}>{item.icon}</div>
                  <div>
                    <p style={{ fontSize: 11, color: "var(--pink)", margin: "0 0 3px 0", fontWeight: 600 }}>
                      {item.label}
                    </p>
                    <p style={{ fontSize: 13, color: "var(--text)", margin: 0, fontWeight: 600 }}>
                      {item.value}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="order-detail-column">
          <div className="order-detail-section" style={{
            background: "var(--surface)",
            padding: 20,
            marginBottom: 18,
          }}>
            <p style={{
              fontSize: 11, fontWeight: 700, color: "#1E40AF",
              textTransform: "uppercase", letterSpacing: "0.07em",
              marginBottom: 14,
              display: "flex", alignItems: "center", gap: 6
            }}><Icons.CheckCircle /> Estado & Pago</p>

            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <p style={{ fontSize: 11, color: "#1E40AF", margin: "0 0 7px 0", fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}>
                  <Icons.Check /> ESTADO ACTUAL
                </p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  <StatusBadge status={order.status} order={order} />
                  {isReturnedOrder(order) && <ReturnedBadge />}
                </div>
              </div>

              <div>
                <p style={{ fontSize: 11, color: "#1E40AF", margin: "0 0 7px 0", fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}>
                  <Icons.Money /> ESTADO DE PAGO
                </p>
                <StatusBadge status={order.payment_status} type="payment" />
              </div>

              {isReturnedOrder(order) && (
                <div style={{
                  background: "rgba(245, 158, 11, 0.12)",
                  border: "1px solid rgba(245, 158, 11, 0.18)",
                  borderRadius: "var(--radius-md)",
                  padding: 14,
                }}>
                  <p style={{ fontSize: 11, color: "#b45309", margin: "0 0 6px 0", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.04em" }}>
                    Orden devuelta
                  </p>
                  <p style={{ fontSize: 13, color: "#92400e", margin: 0, lineHeight: 1.55 }}>
                    {order.return_reason}
                  </p>
                </div>
              )}
              <OrderReturnHandoffPanel incomingHandoff={returnHandoff} history={returnHistory} />
            </div>

            {shouldShowPrimaryAction && (
              <div style={{ marginTop: 16 }}>
                <OrderAssignmentAction
                  order={order}
                  label={primaryLabel}
                  onClick={primaryActionHandler}
                  bare
                />
              </div>
            )}
          </div>

          <div className="order-detail-section" style={{
            background: "var(--surface)",
            padding: 16,  
            marginBottom: 18
          }}>
            <p style={{
              fontSize: 11, fontWeight: 700, color: "#1E40AF",
              textTransform: "uppercase", letterSpacing: "0.07em",
              marginBottom: 12,
              display: "flex", alignItems: "center", gap: 6
            }}><Icons.Clipboard /> Información del Sistema</p>

            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {(() => {
                const items = [
                  { label: "ID Orden", value: order.id?.slice(0, 8), icon: <Icons.Clipboard /> },
                  { label: "Creada", value: created, icon: <Icons.Clock /> },
                  { label: "Responsable", value: displayResponsibleName, icon: <Icons.User /> },
                  ...(order.designer_id ? [{ label: "Diseñador", value: designerName || "Asignado", icon: <Icons.Edit /> }] : []),
                ];
                return items.map((item, index) => (
                  <div key={item.label} style={{
                    display: "grid", gridTemplateColumns: "28px 1fr",
                    gap: 10, alignItems: "center", paddingBottom: 11,
                    borderBottom: index < items.length - 1 ? "1px solid var(--border)" : "none"
                  }}>
                    <div style={{ color: "var(--pink)" }}>{item.icon}</div>
                    <div>
                      <p style={{ fontSize: 11, color: "var(--pink)", margin: "0 0 3px 0", fontWeight: 600 }}>
                        {item.label}
                      </p>
                      <p style={{ fontSize: 13, color: "var(--text)", margin: 0, fontWeight: 600 }}>
                        {item.value}
                      </p>
                    </div>
                  </div>
                ));
              })()}
            </div>
          </div>

          <div className="order-detail-section" style={{
            background: "var(--surface)",
            padding: 16,
            marginBottom: 18
          }}>
            <p style={{
              fontSize: 11, fontWeight: 700, color: "#1E40AF",
              textTransform: "uppercase", letterSpacing: "0.07em",
              marginBottom: 12, display: "flex", alignItems: "center", gap: 8
            }}>
              <Icons.ExternalLink /> Link de Seguimiento
            </p>

            <TrackingLinkField orderId={order.id} />
          </div>
        </div>
      </div>

      {hasAssets && (
        <div className="order-detail-section" style={{
          background: "var(--surface)",
          padding: 20,
        }}>
          <p style={{
            fontSize: 11, fontWeight: 700, color: "#1E40AF",
            textTransform: "uppercase", letterSpacing: "0.07em",
            marginBottom: 16,
            display: "flex", alignItems: "center", gap: 8
          }}>
            <Icons.Paperclip /> Archivos Adjuntos
          </p>

          <div style={{ display: "grid", gridTemplateColumns: order.preview_image && orderFileUrls.length > 0 ? "1fr 1fr" : "1fr", gap: 16 }}>
            {order.preview_image && (() => {
              const previewKey = getPreviewAssetKey(order.preview_image);
              const previewUrl = resolvedAssetUrls[previewKey];
              const previewUnavailable = assetResolutionErrors[previewKey];

              return (
              <div>
                <p style={{ fontSize: 12, fontWeight: 600, color: "var(--pink)", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                  <Icons.Eye /> Orden de Trabajo
                </p>
                {previewUrl ? (
                  <a href={previewUrl} target="_blank" rel="noreferrer" style={{ textDecoration: "none" }}>
                    <img
                      src={previewUrl}
                      alt="preview"
                      style={{
                        width: "100%",
                        borderRadius: "var(--radius-md)",
                        border: "1px solid var(--border)",
                        cursor: "pointer",
                        transition: "transform 0.2s, box-shadow 0.2s",
                      }}
                      onMouseEnter={(event) => { event.target.style.transform = "scale(1.02)"; event.target.style.boxShadow = "0 8px 24px rgba(0,0,0,0.12)"; }}
                      onMouseLeave={(event) => { event.target.style.transform = "scale(1)"; event.target.style.boxShadow = "none"; }}
                    />
                  </a>
                ) : (
                  <div className="order-detail-img-loading" style={{ height: 120 }}>
                    <span className="ps-btn-spinner" />
                    {previewUnavailable ? "Imagen no disponible" : "Cargando imagen..."}
                  </div>
                )}
              </div>
              );
            })()}

            {orderFileUrls.length > 0 && (
              <div>
                <p style={{ fontSize: 12, fontWeight: 600, color: "#1E40AF", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                  <Icons.Brush /> Diseño del cliente
                </p>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {orderFileUrls.map((url, index) => (
                    <FileCard
                      key={`${url}-${index}`}
                      name={getFileNameFromUrl(url)}
                      url={url}
                      secondaryText={order.order_design_type === "INTERNAL_DESING" ? "Diseño interno" : order.order_design_type === "EXTERNAL_DESING" ? "Diseño externo" : ""}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
          {referenceImageUrls.length > 0 && (
            <div style={{ marginTop: 16 }}>
              <p style={{ fontSize: 12, fontWeight: 600, color: "var(--text-sub)", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}>
                <Icons.Image /> Imágenes de referencia
              </p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 12 }}>
                {referenceImageUrls.map((url, index) => {
                  const referenceKey = getReferenceAssetKey(url, index);
                  const referenceUrl = resolvedAssetUrls[referenceKey];
                  const referenceUnavailable = assetResolutionErrors[referenceKey];

                  return referenceUrl ? (
                    <a key={referenceKey} href={referenceUrl} target="_blank" rel="noreferrer" style={{ textDecoration: "none", flex: "0 0 auto" }}>
                      <img
                        src={referenceUrl}
                        alt={`Ref ${index + 1}`}
                        style={{
                          width: 120,
                          height: 120,
                          objectFit: "cover",
                          borderRadius: "var(--radius-md)",
                          border: "1px solid var(--border)",
                          cursor: "pointer",
                          transition: "transform 0.2s, box-shadow 0.2s",
                        }}
                        onMouseEnter={(event) => { event.target.style.transform = "scale(1.05)"; event.target.style.boxShadow = "0 4px 16px rgba(0,0,0,0.15)"; }}
                        onMouseLeave={(event) => { event.target.style.transform = "scale(1)"; event.target.style.boxShadow = "none"; }}
                      />
                    </a>
                  ) : (
                    <div key={referenceKey} className="order-detail-img-loading" style={{ width: 120, height: 120 }}>
                      <span className="ps-btn-spinner" />
                      {referenceUnavailable ? "No disponible" : "Cargando..."}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      <OrderParticipationTimeline orderId={order.id} />

      </div>
    </Modal>
  );
}
